import React from "react";
import { createChatBotMessage } from "react-chatbot-kit";

import BenefitsOptions from "./BenefitsOptions";
import BenefitsComparisonList from "./BenefitsComparisonList";

const config = {
  botName: "DWBot",
  initialMessages: [
    createChatBotMessage("Hello,  Welcome! Here are the list of DW benefits :", {
      widget: "benefitsOptions",
    }),
  ],
  customStyles: {
    botMessageBox: {
      backgroundColor: "#2898ec",
    },
    chatButton: {
      backgroundColor: "#2898ec",
    },
  },
  widgets: [
    {
      widgetName: "benefitsOptions",
      widgetFunc: (props) => <BenefitsOptions {...props} />,
    },
    {
      widgetName: "dwbWidget",
      widgetFunc: (props) => <BenefitsComparisonList {...props} />,
      props: {
        options: [
          {
            text: "1. Ease of Access (Always online) : When you create a Will using an online platform like  Xyz you can make changes or access the document from anywhere in the world - using your mobile phone or any other digital device.",
            id: 1,
          },
          {
            text: "2. Unlimited updates.DWill yearly subscription model means you can update the document as many times as you like - whenever you like",
            id: 2,
          }
        ],
      },
    },
  ],
};

export default config;
