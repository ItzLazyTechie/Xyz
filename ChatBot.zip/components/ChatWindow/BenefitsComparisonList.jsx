import React from "react";

import "./chatwindow.css";

const BenefitsComparisonList = (props) => {
  console.log(props);
  const linkMarkup = props.options.map((link) => (
    <li key={link.id} className="dw-list-item">
      <a
        target="_blank"
        rel="noopener noreferrer"
        className="dw-list-item-url"
      >
        {link.text}
      </a>
    </li>
  ));

  return <ul className="dw-list">{linkMarkup}</ul>;
};

export default BenefitsComparisonList;
