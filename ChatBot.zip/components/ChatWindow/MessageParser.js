// MessageParser starter code in MessageParser.js
class MessageParser {
  constructor(actionProvider) {
    this.actionProvider = actionProvider;
  }

  parse(message) {
    const userEnteredMessage = message.toLowerCase();

    if (userEnteredMessage.includes("hello") || userEnteredMessage.includes("hi")) {
      this.actionProvider.greetUser();
    }

    if (userEnteredMessage.includes("yes")) {
      this.actionProvider.handleBenefitsOverXyz();
    }
	
	  if (userEnteredMessage.includes("no")) {
      this.actionProvider.greetThankYou();
    }
  }
}

export default MessageParser;
