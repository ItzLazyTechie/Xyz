class ActionProvider {
  constructor(createChatBotMessage, setStateFunc) {
    this.createChatBotMessage = createChatBotMessage;
    this.setState = setStateFunc;
  }

  // new method
  greetUser() {
    const greetingMessage = this.createChatBotMessage("Hello,  Would You like to know the Benefits, Press YES or NO to continue!");
    this.updateChatbotState(greetingMessage);
  }
  
  displayWillBenefits() {
	  const willBenefitsMsg = this.createChatBotMessage("Here are the list of benefits :");
	  this.updateChatbotState(willBenefitsMsg);
  }
  
  greetThankYou() {
	const greetingMessage = this.createChatBotMessage("ThankYou! :)");
    this.updateChatbotState(greetingMessage);
  }

  handleBenefitsOverXyz= () => {
    const message = this.createChatBotMessage(
      "Fantastic, Below are the benefits over Xyz.",
      {
        widget: "dwbWidget",
      }
    );

    this.updateChatbotState(message);
  };

  updateChatbotState(message) {
    // NOTICE: This function is set in the constructor, and is passed in from the top level Chatbot component. The setState function here actually manipulates the top level state of the Chatbot, so it's important that we make sure that we preserve the previous state.

    this.setState((prevState) => ({
      ...prevState,
      messages: [...prevState.messages, message],
    }));
  }
}

export default ActionProvider;
