import React from "react";

import "./chatwindow.css";

const BenefitsOptions = (props) => {
  const options = [
    {
      text: "1.  Wealth Distribution: Distribute your assets in the best way you see fair.",
      handler: props.actionProvider.handleJavascriptList,
      id: 1,
    },
    { text: "2. Family Protection : Ensure that your family keeps smiling with and even after you.",
	handler: () => {}, id: 2 },
    { text: "3. Avoid Disputes: Will gives legal assurance that your family receives wealth as per your wish", handler: () => {}, id: 3 },
    { text: "4. Tax Benefits: NRIs can benefit while filing for tax if separate Will for India is made", handler: () => {}, id: 4 },
  ];

  const optionsMarkup = options.map((option) => (
  <>
      <li key={option.id} className="dw-list-item">
      <a
        target="#"
        rel="noopener noreferrer"
        className="dw-list-item-url"
      >
        {option.text}
      </a>
    </li>
	 
	</>
	
	
  ));

  return  ( 
  <div>
  
  <ul className="dw-list">{optionsMarkup}</ul>
  <h6> Would you like to know the benefits over xyz. Press the below Button to continue! </h6>
   <button className="options-button" onClick={props.actionProvider.handleBenefitsOverXyz}>Click Benefits Over Xyz</button>
	  
	  </div>);
};

export default BenefitsOptions;
