import React from "react";
import Chatbot from "react-chatbot-kit";
import "./App.css";
import {useState} from "react";
import pic from "./components/ChatWindow/chatbot-icon.jpg";

import ActionProvider from "./components/ChatWindow/ActionProvider";
import MessageParser from "./components/ChatWindow/MessageParser";
import config from "./components/ChatWindow/config";

function App() {
	
	const [displayChatWindow, setDisplayChatWindow] =  useState(false);
	
	function handleChatWindow() {
		setDisplayChatWindow(true);
	}
  return (
    <div className="App chat-icon-position">
	 {
		!displayChatWindow ?
		<a onClick = {handleChatWindow}>	<img  src={pic}  style={{width:"60px", height:"45px"}} /></a>
		: null
	 } 
	
    {
		displayChatWindow ?
        <Chatbot
          config={config}
          actionProvider={ActionProvider}
          messageParser={MessageParser}
        /> : null
	}
     
    </div>
  );
}

export default App;
